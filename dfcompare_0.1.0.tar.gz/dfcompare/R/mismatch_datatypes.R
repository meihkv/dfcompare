mismatch_datatypes = function (source, target){
  #finds common columns and checks if datatypes match
  #returns a dataframe vector
  src_name = deparse(substitute(source,env=parent.frame()))
  tgt_name = deparse(substitute(target,env=parent.frame()))

  common = common_colnames(source,target)

  dt_src = sapply(source[common], class)
  dt_tgt = sapply(target[common], class)


  df = as.data.frame(cbind(dt_tgt, dt_src, dt_src != dt_tgt))
  names(df) = c(src_name, tgt_name, "mismatch")

  return(df)

}
